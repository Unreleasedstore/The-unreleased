
document.getElementById('year').textContent = new Date().getFullYear();
const joinBtn = document.getElementById('joinBtn');
const previewBtn = document.getElementById('previewBtn');
const earlyBtn = document.getElementById('earlyAccess');
if(joinBtn) joinBtn.addEventListener('click', ()=> document.getElementById('join').scrollIntoView({behavior:'smooth'}));
if(previewBtn) previewBtn.addEventListener('click', ()=> document.getElementById('collections').scrollIntoView({behavior:'smooth'}));
if(earlyBtn) earlyBtn.addEventListener('click', ()=> document.getElementById('join').scrollIntoView({behavior:'smooth'}));
document.addEventListener('DOMContentLoaded', ()=>{ document.querySelectorAll('.fade-in').forEach((el,i)=>{ el.style.animationDelay = (i*0.08)+'s'; }); });
window.addEventListener('scroll', ()=>{ const sc = window.scrollY; document.querySelectorAll('.parallax').forEach((el)=>{ el.style.transform = 'translateY(' + (sc * -0.02) + 'px)'; }); const slices = document.querySelectorAll('.logo-img'); slices.forEach((s,i)=> s.style.transform = 'translateX(' + (Math.sin(sc/120 + i)*1.2) + 'px)'); });
document.querySelectorAll('.lookbook-item').forEach(el=>{ el.addEventListener('mouseenter', ()=> el.style.transform='scale(1.02) rotate(-0.4deg)'); el.addEventListener('mouseleave', ()=> el.style.transform='none'); });
function formSuccess(){ setTimeout(()=>{ alert('Thanks — you are on the list!'); },200); return true; }
document.addEventListener('keydown', (e)=>{ if(e.key.toLowerCase()==='j') document.getElementById('join').scrollIntoView({behavior:'smooth'}); });
