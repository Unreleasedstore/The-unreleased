
THE UNRELEASED — Cyberpunk Final (v3)
------------------------------------
Files ready for Netlify drag & drop deployment.

- index.html (uses Formsubmit to send emails to theunreleasedstore@gmail.com)
- css/styles.css
- js/main.js
- images/logo/logo.png (your uploaded logo)
- images/lookbook/placeholder*.svg

Deploy:
1. Download and unzip the package
2. Go to https://app.netlify.com/drop and drag the folder
3. Site will be live instantly. Form submissions will email theunreleasedstore@gmail.com via Formsubmit.co

Notes:
- To replace lookbook images, drop files into images/lookbook/ and keep names or update index.html.
- If you want a transparent SVG of your logo, say 'export svg' and I'll generate it.
